using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Timers;
using Sandbox;
using Sandbox.Common;
using Sandbox.Common.ObjectBuilders.Gui;
using Sandbox.Common.ModAPI;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Engine.Physics;
using Sandbox.Engine.Multiplayer;
using Sandbox.Game;
using Sandbox.Game.Entities;
using Sandbox.Game.Gui;
using Sandbox.Game.Weapons;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Interfaces;
using VRage.Common.Utils;
using VRageMath;
using VRage;
using VRage.ObjectBuilders;
using VRage.Components;
using VRage.ModAPI;
using VRage.Utils;
using ZJ.Utils;
using Sandbox.Graphics.GUI;
using Sandbox.ModAPI.Ingame;
using VRage.Input;

namespace ZJ.GuidedMissileCore
{

    public class GuidedMissileSingleton {
        private class MissileDataTriplet
        {
            public IMyEntity Missile { get; set; }
            public IMyEntity Target { get; set; }
            public long TrackedFrames { get; set; }
            //   public int TimesUpdated = 0;

            public MissileDataTriplet(IMyEntity missile, IMyEntity target, long safetyTimer)
            {
                Missile = missile;
                Target = target;
                TrackedFrames = -safetyTimer;
            }
            public MissileDataTriplet(IMyEntity missile, IMyEntity target)
            {
                Missile = missile;
                Target = target;
                TrackedFrames = 0;
            }
            public void SetEmpty()
            {
                Missile = null;
                Target = null;
            }
            public bool IsExpired()
            {
                if (Missile == null) return true;
                if (Target == null) return true;
                if (Missile.MarkedForClose) return true;
                if (Target.MarkedForClose) return true;
                return false;
            }

            public void Tick()
            {
                TrackedFrames++;
            }
            public bool SafetyTimerIsOver()
            {
                return (TrackedFrames > 0);
            }
        }

        
        private static GuidedMissileSingleton INSTANCE = null;

        private Dictionary<long, MissileDataTriplet> guidedMissileDict; //A dictionary. the missiles are the keys, their targets the values.
        private HashSet<long> deleteSet;

        private HashSet<IMyEntity> turretSet;
        private HashSet<IMyEntity> deleteTurretSet;

        private GuidedMissileSingleton() {
            guidedMissileDict = new Dictionary<long, MissileDataTriplet>();
            deleteSet = new HashSet<long>();
            turretSet = new HashSet<IMyEntity>();
            deleteTurretSet = new HashSet<IMyEntity>();
            Log.Info("GuidedMissileSingleton was created.");   
        }

        public static GuidedMissileSingleton GetInstance() {
            if (INSTANCE == null) {
                INSTANCE = new GuidedMissileSingleton();        
            }
            return INSTANCE;         
        }

        public static void Update()
        {
            GetInstance().UpdateBeforeSimulation();
        }

        public bool AddMissileToDict(IMyEntity missile, IMyEntity target, long safetyTimer)
        {
            //  Log.Info("AddMissileToDict was called with something of type " + missile.GetType().ToString());
            if (!(missile.GetType().ToString() == "Sandbox.Game.Weapons.MyMissile")) return false;
            //  if ((!Object.ReferenceEquals(missile.GetType().ToString(), "MyMissile"))&&(!Object.ReferenceEquals(missile.GetType().ToString(), "Sandbox.Game.Weapons.MyMissile"))) return false; //probably not the best way?
            //  Log.Info("didnt discard it due to its type");
            if ((missile == null) || (target == null)) return false;
            //  Log.Info("didnt discard it due to null args");
            if (guidedMissileDict.ContainsKey(missile.EntityId)) return false;
            //  Log.Info("didnt discard already contained key");
            guidedMissileDict.Add(missile.EntityId, new MissileDataTriplet(missile, target, safetyTimer));
            Log.Info("Added missile " + missile.EntityId + " with Target " + target.EntityId + " and safetyTimer " + safetyTimer + " Frames to the dictionary!");
            return true;
        }
 
        public GuidedMissileControlStationHook GetControlStationHook(IMyEntity turret)
        {

            MyEntityComponentContainer componentContainer = turret.Components;
            // Log.Error("contains?" + componentContainer.Has<GuidedMissileControlStationHook>());
            //GuidedMissileTargetGridHook hook = componentContainer.Get<GuidedMissileTargetGridHook>();
            //Log.Info("success is not null?" + (hook != null));
            GuidedMissileControlStationHook controlStationHook = null;
            foreach (MyComponentBase comp in componentContainer)
            {
                if (comp is GuidedMissileControlStationHook)
                {
                    controlStationHook = (GuidedMissileControlStationHook)comp;
                    // Log.Info("iterating over: " + comp.GetType().ToString());
                }
            }
            return controlStationHook;
        }
        public bool RemoveMissileFromDict(IMyEntity missile)
        {
            if (missile == null) return false;
            if (!guidedMissileDict.ContainsKey(missile.EntityId)) return false;
            guidedMissileDict.Remove(missile.EntityId);
            return true;
        }

        public bool MissileIsGuided(IMyEntity missile)
        {
            return guidedMissileDict.ContainsKey(missile.EntityId);
        }

        public bool AddTurretToSet(IMyEntity turret)
        {
            Log.Info("tried to add turret to set");
            return turretSet.Add(turret);
        }

        public bool RemoveTurretFromSet(IMyEntity turret)
        {
            Log.Info("tried to remove turret from Set");
            return turretSet.Remove(turret);
        }

        public void UpdateTurret(IMyEntity turret)
        {
            //    Log.Info("updated turret");
            if (!turret.MarkedForClose)
            {
                GetControlStationHook(turret).UpdateManually();
            }

        }



        public void UpdateBeforeSimulation()
        {
  
            //      Log.Info("core class was updated.");
            Dictionary<long, MissileDataTriplet>.KeyCollection keyCollection = guidedMissileDict.Keys;
            MissileDataTriplet missileData;
            foreach (long key in keyCollection)
            {
                if (guidedMissileDict.TryGetValue(key, out missileData))
                {
                    if (missileData.IsExpired())
                    {
                        deleteSet.Add(key);
                        missileData.SetEmpty();
                    }
                    else
                    {
                        if (missileData.SafetyTimerIsOver())
                        {
                            //     Log.Info("turning missile");

                            //     var linVel = missileData.Missile.Physics.LinearVelocity;

                            float TURNING_SPEED = 0.1f;

                            Vector3 diffVelocity = missileData.Target.GetTopMostParent().Physics.LinearVelocity - missileData.Missile.Physics.LinearVelocity;

                            Vector3 targetDirection = Vector3.Normalize(missileData.Target.GetPosition() + diffVelocity - missileData.Missile.GetPosition());
                            Matrix targetMatrix = Matrix.CreateWorld(missileData.Missile.GetPosition(), targetDirection, Vector3.Transform(targetDirection, Matrix.CreateFromYawPitchRoll((float)Math.PI, 0f, 0f)));

                            var slerpMatrix = Matrix.Slerp(missileData.Missile.WorldMatrix, targetMatrix, TURNING_SPEED);
                            missileData.Missile.SetWorldMatrix(slerpMatrix);

                            //   missileData.Missile.Physics.LinearVelocity = Vector3.Normalize(linVel) * missileData.Missile.WorldMatrix.Forward; //+ Vector3.Normalize(slerpMatrix.Forward)*50;

                        }
                        missileData.TrackedFrames++;
                    }
                }
            }



            foreach (long deleteId in deleteSet)
            {
                guidedMissileDict.Remove(deleteId);
            }
            deleteSet.Clear();

            foreach (IMyEntity turret in turretSet)
            {
                if (turret.MarkedForClose) { deleteTurretSet.Add(turret); }
                else
                {
                    UpdateTurret(turret);
                }
            }
            turretSet.ExceptWith(deleteTurretSet);
            deleteTurretSet.Clear();
            
        }
    
    
    }
    [MySessionComponentDescriptor(MyUpdateOrder.BeforeSimulation)]
    public class GuidedMissileCore : MySessionComponentBase
    {
 
        public static bool init { get; private set; }
        public void Init()
        {

            Log.Info("Initialized.");
            init = true;
        }

       
        protected override void UnloadData()
        {
            Log.Info("Mod unloaded.");
            Log.Close();
            init = false;
        }

        public override void UpdateBeforeSimulation()
        {
            if (!init)
            {
                if (MyAPIGateway.Session == null)
                    return;

                Init();
            }
            else {
                GuidedMissileSingleton.Update();
            }
        }
    }

    [MyEntityComponentDescriptor(typeof(MyObjectBuilder_SmallMissileLauncher), "GuidedMissileLauncher")]
    public class GuidedMissileLauncherHook : MyGameLogicComponent
    {

        private MyObjectBuilder_EntityBase objectBuilder;
        public override void Init(MyObjectBuilder_EntityBase objectBuilder)
        {
            this.objectBuilder = objectBuilder;
         //   Log.Error("A missile launcher was created");
        //    MyAPIGateway.Utilities.ShowNotification("A missile launcher was created");
            Entity.NeedsUpdate |= MyEntityUpdateEnum.BEFORE_NEXT_FRAME | MyEntityUpdateEnum.EACH_FRAME | MyEntityUpdateEnum.EACH_10TH_FRAME;
        }







        public override void Close()
        {
            objectBuilder = null;

        }

        public override MyObjectBuilder_EntityBase GetObjectBuilder(bool copy = false)
        {
            return copy ? (MyObjectBuilder_EntityBase)objectBuilder.Clone() : objectBuilder;
        }

      //  private bool toldBoundingBox = false; 

        public override void UpdateBeforeSimulation()
        {
            try
            {

                BoundingBoxD box = (BoundingBoxD)Entity.WorldAABB;
         /**       if (!toldBoundingBox) {
                    Log.Info("WorldBBHr: "+box.Min+" to " +box.Max);

                    box = (BoundingBoxD)Entity.WorldAABB;
                    Log.Info("WorldBB: " + box.Min + " to " + box.Max);
                    box = (BoundingBoxD)Entity.LocalAABB;
                    Log.Info("LocalBB: " + box.Min + " to " + box.Max);
                    box = (BoundingBoxD)Entity.LocalAABBHr;
                    Log.Info("LocalBBHr: " + box.Min + " to " + box.Max);

                    Log.Info("And now for the parent:");
                    box = (BoundingBoxD)Entity.GetTopMostParent().WorldAABBHr;

                    Log.Info("WorldBBHr: "+box.Min+" to " +box.Max);

                    box = (BoundingBoxD)Entity.GetTopMostParent().WorldAABB;
                    Log.Info("WorldBB: " + box.Min + " to " + box.Max);
                    box = (BoundingBoxD)Entity.GetTopMostParent().LocalAABB;
                    Log.Info("LocalBB: " + box.Min + " to " + box.Max);
                    box = (BoundingBoxD)Entity.GetTopMostParent().LocalAABBHr;
                    Log.Info("LocalBBHr: " + box.Min + " to " + box.Max);
                    toldBoundingBox = true;

                }

                box = (BoundingBoxD)Entity.WorldAABB; **/

                List<IMyEntity> entitiesFound = MyAPIGateway.Entities.GetEntitiesInAABB(ref box);
                BoundingSphereD sphere = new BoundingSphereD(Entity.GetPosition(), 1000);
      /**          List<IMyEntity> targetsFound = MyAPIGateway.Entities.GetEntitiesInSphere(ref sphere);
                Random rnd = new Random();
                IMyEntity randomTarget = targetsFound[rnd.Next(0, targetsFound.Count)]; **/

                
                foreach (IMyEntity ent in entitiesFound)
                {


                    if (ent.GetType().ToString() == "Sandbox.Game.Weapons.MyMissile") //CHECK FOR OWNER OR SOMETHING ;_;
                    {
                        GuidedMissileSingleton.GetInstance().AddMissileToDict(ent, GuidedMissileTargetGridHook.GetMissileTargetForGrid(Entity.GetTopMostParent()), 50);
                    }
                }

                //       if (ent.GetType().ToString() == "Sandbox.Game.Entities.Character.MyCharacter") Log.Error("found a player");
                // Log.Info("found: " + ent.GetType().ToString());
                     //   if (!missileSet.Contains(ent)) {

                        //ent.gettype cast??

                    //    var lmat = ent.LocalMatrix;
                     //   Matrix.Rescale(ref lmat, 5f);
                    //    ent.SetLocalMatrix(lmat);
                  //      var oId = ent.GetType().GetField("OwnerId").GetValue(ent);
                      //  if (((IMyCubeBlock)Entity).OwnerId == ((long)oId)) {
                        
                    //    }
                        
                       //     if((ent.Physics != null)&&(Entity.Physics.LinearVelocity != null)) ent.Physics.LinearVelocity += Entity.Physics.LinearVelocity;
                     //   }
                       

                
        /**        foreach (IMyEntity missile in missileSet)
                {

                    if (missile.MarkedForClose)
                    {
                        
                        deleteSet.Add(missile);
                       
                    }
                    else
                    {
                        //Safety
                        float TURNING_SPEED = 0.02f;
                   //     float SAFETY_DISTANCE = 20;
                  //      if (Math.Abs((Entity.GetPosition() - missile.GetPosition()).Normalize()) > SAFETY_DISTANCE) {

                            missileTarget = Entity; //DEBUG
                            Vector3 targetDirection = Vector3.Normalize(missileTarget.GetPosition() - missile.GetPosition());
                            Matrix targetMatrix = Matrix.CreateWorld(missileTarget.GetPosition(), targetDirection, Vector3.Transform(targetDirection, Matrix.CreateFromYawPitchRoll((float)Math.PI, 0f, 0f)));
                            
                            var slerpMatrix = Matrix.Slerp(missile.WorldMatrix, targetMatrix, TURNING_SPEED);
                            missile.SetWorldMatrix(slerpMatrix);
                        
                        
                     //   }
                        

              

                        //    Vector3 newDirection = speed * (0.05f * targetDirection + 0.95f * Vector3.Normalize(vel));

                   //     var matrix = MatrixD.CreateFromDir(targetDirection);
                    //    Log.Error("missile.WorldMatrix:" + missile.WorldMatrix);
                        
                 //       var oldMatrix = missile.WorldMatrix;
                 //       var diffAngle = MyUtils.GetAngleBetweenVectors(missile.WorldMatrix.Forward, targetDirection);
                       
                     //   Log.Error("diffAngle:" + diffAngle);




        //                var angleX = MyUtils.GetAngleBetweenVectors(missile.WorldMatrix.Up, targetDirection);
        //                var AngleY = MyUtils.GetAngleBetweenVectors(missile.WorldMatrix.Forward, targetDirection);
        //                var matrixX = Matrix.CreateFromAxisAngle(missile.WorldMatrix.Forward, 0.05f);
        //                var matrixY = Matrix.CreateFromAxisAngle(missile.WorldMatrix.Left, 0.05f);  
               //         var distanceToOrigin = missile.GetPosition();
                   //     var translateToOrigin = Matrix.CreateTranslation(-1f * distanceToOrigin);
                   //     var translateFromOrigin = Matrix.CreateTranslation(distanceToOrigin);

                   //     if (Math.Abs(diffAngle) < TURNING_SPEED)                         
                   //     { 
                        //    rotateMatrix = Matrix.CreateFromAxisAngle(rotationAxis, (float)(diffAngle*180 / Math.PI)); 
                            
                   //     }
                   //     else                         
                   //     {
                    //        if (diffAngle > 0.5f * Math.PI)
                    //        {
                    //            rotateMatrix = Matrix.CreateFromAxisAngle(rotationAxis, -TURNING_SPEED);
                    //        }
                     //       else {
                   //             rotateMatrix = Matrix.CreateFromAxisAngle(rotationAxis, TURNING_SPEED);
                    //        }
                            
                     //   }

                       



                     //   missile.SetWorldMatrix(translateFromOrigin * rotateMatrix * translateToOrigin *oldMatrix);
                        
                        //   deleteSet.Add(missile);
                      //     missileSet.ExceptWith(deleteSet);
                      //     Log.Error("missileSet contains removed missile before second     except with " + missileSet.Contains(missile));
                       //     missile.SetWorldMatrix(matrixY * matrixX * oldMatrix);
                    }
                }
       
                missileSet.ExceptWith(deleteSet);
              //  Log.Error("missileSet contains removed missile after except with " + missileSet.Contains(missile));
                deleteSet.Clear();
                
                **/

            }
            catch (Exception e)
            {
                Log.Error(e);
                MyAPIGateway.Utilities.ShowNotification("" + e.ToString(), 1000, MyFontEnum.Red);
            }
        }
    }


 /**   [MyEntityComponentDescriptor(typeof(MyObjectBuilder_Missile))] //, "GuidedMissile" ??
    public class GuidedMissileHook : MyGameLogicComponent
    {
        private MyObjectBuilder_EntityBase objectBuilder;
        public IMyEntity missileTarget = null;

        public override void Init(MyObjectBuilder_EntityBase objectBuilder)
        {
            this.objectBuilder = objectBuilder;
            MyAPIGateway.Utilities.ShowNotification("Hello I am awesomerocket", 1000, MyFontEnum.Red);
            Entity.NeedsUpdate |= MyEntityUpdateEnum.BEFORE_NEXT_FRAME | MyEntityUpdateEnum.EACH_FRAME | MyEntityUpdateEnum.EACH_10TH_FRAME;
        }

        public override void UpdateOnceBeforeFrame()
        {
            try
            {
                MyAPIGateway.Utilities.ShowNotification("Hello I am awesome", 1000, MyFontEnum.Red);
                BoundingSphereD mysphere = (BoundingSphereD)Entity.LocalVolume;

                IMyEntity foundEntity = MyAPIGateway.Entities.GetIntersectionWithSphere(ref mysphere, Entity, null);
                MyEntityComponentContainer componentContainer = foundEntity.Components;
                // Log.Error("contains?" + componentContainer.Has<GuidedMissileTargetGridHook>());
                GuidedMissileTargetGridHook hook = componentContainer.Get<GuidedMissileTargetGridHook>();
                //     Log.Error("success?" + (hook != null));
                
          //      foreach (MyEntityComponentContainer component in componentList) {
          //          if (component is GuidedMissileTargetGridHook) {
          //              this.missileTarget = ((GuidedMissileTargetGridHook)component).GetMissileTarget();
           //             Log.Error("found a valid component!");
          //          }                
        //        } 

                this.missileTarget = hook.GetMissileTarget();
                Log.Error("Found an entity and got a missile target!");

            }
            catch (Exception e)
            {
                Log.Error(e);
            }
        }

        public override void Close()
        {
            objectBuilder = null;
            missileTarget = null;
        }

        public override MyObjectBuilder_EntityBase GetObjectBuilder(bool copy = false)
        {
            return copy ? (MyObjectBuilder_EntityBase)objectBuilder.Clone() : objectBuilder;
        }
        public override void UpdateBeforeSimulation()
        {
            if (missileTarget != null)
            {

                IMyEntity missile = Entity as IMyEntity;
                Vector3 vel = missile.Physics.LinearVelocity;
                float speed = vel.Normalize();

                Vector3 targetDirection = missileTarget.GetPosition() - missile.GetPosition();

                targetDirection = Vector3.Normalize(targetDirection);
                Vector3 newDirection = speed * (0.05f * targetDirection + 0.95f * Vector3.Normalize(vel));
                missile.Physics.LinearVelocity = newDirection;

            }
            else
            {
                Log.Error("Missile Target was null");
            }
        }
    } **/

    

    
    [MyEntityComponentDescriptor(typeof(MyObjectBuilder_CubeGrid))]
    public class GuidedMissileTargetGridHook : MyGameLogicComponent
    {
        public static bool SetMissileTargetForGrid(IMyEntity grid, IMyEntity target) {
            MyEntityComponentContainer componentContainer = grid.Components;
            GuidedMissileTargetGridHook targetGridHook = null;
            foreach (MyComponentBase comp in componentContainer)
            {
                if (comp is GuidedMissileTargetGridHook)
                {
                    targetGridHook = (GuidedMissileTargetGridHook)comp;
                    // Log.Info("iterating over: " + comp.GetType().ToString());
                }
            }
            return targetGridHook.SetMissileTarget(target);
        }

        public static IMyEntity GetMissileTargetForGrid(IMyEntity grid) {

            MyEntityComponentContainer componentContainer = grid.Components;
            GuidedMissileTargetGridHook targetGridHook = null;
            foreach (MyComponentBase comp in componentContainer)
            {
                if (comp is GuidedMissileTargetGridHook)
                {
                    targetGridHook = (GuidedMissileTargetGridHook)comp;
                    // Log.Info("iterating over: " + comp.GetType().ToString());
                }
            }
            return targetGridHook.GetMissileTarget();            
        }

        private MyObjectBuilder_EntityBase objectBuilder;
        public IMyEntity missileTarget = null;

        public override void Init(MyObjectBuilder_EntityBase objectBuilder)
        {
            this.objectBuilder = objectBuilder;
     //       MyAPIGateway.Utilities.ShowNotification("Hello I am awesomegrid", 1000, MyFontEnum.Red);
        }

        public bool SetMissileTarget(IMyEntity target) //returns true if operation was succesful and this.target is not null after the operation
        {
            try {

                this.missileTarget = target;
                if (this.missileTarget != null) return true;
                 return false;
            } catch {
                return false;            
            }          
        return false;
        }

        public IMyEntity GetMissileTarget() {
            return missileTarget;
        }
        public override void Close()
        {
            objectBuilder = null;
        }

        public override MyObjectBuilder_EntityBase GetObjectBuilder(bool copy = false)
        {
            return copy ? (MyObjectBuilder_EntityBase)objectBuilder.Clone() : objectBuilder;
        }
    }
    [MyEntityComponentDescriptor(typeof(MyObjectBuilder_LargeMissileTurret), "GuidedMissileTargeter")]
    public class GuidedMissileControlStationHook : MyGameLogicComponent
    {

        private MyObjectBuilder_EntityBase objectBuilder;
        public override void Init(MyObjectBuilder_EntityBase objectBuilder)
        {
            this.objectBuilder = objectBuilder;
            
            Log.Info("A missile Control turret was created");
            try
            {
                Log.Info("we attempt to add our turret to the set " + GuidedMissileSingleton.GetInstance().AddTurretToSet(Entity));
            }
            catch {
                Log.Info("apparently entity or something else was null...tracking");
                Log.Info("GuidedMissileSingleton.GetInstance: " + GuidedMissileSingleton.GetInstance());
                Log.Info("Entity: " + Entity);
            }
            Entity.NeedsUpdate |= MyEntityUpdateEnum.EACH_10TH_FRAME;
        }







        public override void Close()
        {
           // Log.Info("called close on guidance station");

            objectBuilder = null;

        }

        public override MyObjectBuilder_EntityBase GetObjectBuilder(bool copy = false)
        {
            return copy ? (MyObjectBuilder_EntityBase)objectBuilder.Clone() : objectBuilder;
        }


        private bool playerEntered = false;
        private void SetPlayerStatus(bool status) {

            playerEntered = status;
            if (status == true) {
                ShowTargetScreen();
            }
            if (status == false) {
                HideTargetScreen();
            }
            Log.Info("Set player status to " + status);
        
        }

        public void ShowTargetScreen() {
    //        Action<ResultEnum> myAction = delegate(ResultEnum e) { Log.Info("A button was clicked: " + e.ToString()); };
    //        MyAPIGateway.Utilities.ShowMissionScreen("Valid Targets", "TestPrefix", "Choose a Target", "GMS", myAction, "Close");
        }

        public void HideTargetScreen() { }
        public override void UpdateAfterSimulation10() {
       //     Log.Info("Updated after Sim 10");
        }
        public override void UpdatingStopped() {
         //   Log.Error("Updating stopped");
        }
        public bool AssignTarget(IMyEntity target) {
            if (target == null) return false;
            // if(target.OwnerId == Entity.OwnerId) return false; //faction check?

            bool success = GuidedMissileTargetGridHook.SetMissileTargetForGrid(Entity.GetTopMostParent(), target);
            if(success) MyAPIGateway.Utilities.ShowNotification("" + target.DisplayName + " was set as missile target!", 1000, MyFontEnum.Red);
            return success;   
        }

        public void UpdateManually() {
            try
            {
           //     if (MyInput.Static.IsPrimaryButtonPressed()) Log.Info("primary button pressed!");
         //       Log.Info("Updating manually");
                //player in cockpit?
                //scan for entities in antenna range
                //filter for grid of certain mass
                //display as a list with clickables? or on hud with clickables on enemies
                // onClick for those, Grid-set target
                //   Log.Info("updating cockpit 10");
                //IMyHudObjectiveLine objective = MyAPIGateway.Utilities.GetObjectiveLine();
                bool playerEntered = false;
                IMyPlayerCollection allPlayers = MyAPIGateway.Players;
                IMyPlayer currentPlayer = null;
                List<IMyPlayer> playerList = new List<IMyPlayer>();
                allPlayers.GetPlayers(playerList, null);
                foreach (IMyPlayer player in playerList)
                {
                    if (player.Controller.ControlledEntity.Entity != null)
                    {
                        if (player.Controller.ControlledEntity.Entity.EntityId == Entity.EntityId)
                        {

                            if (MyAPIGateway.Session.Player == player)
                            {
                                // Log.Info("the correct player entered the command station");
                                currentPlayer = player;
                                if (playerEntered == false) playerEntered = true;
                            }
                        }
                    }
                }
                string pId = "";
                if (currentPlayer != null)
                {
                    if (currentPlayer.Controller.ControlledEntity.Entity != null) pId = currentPlayer.Controller.ControlledEntity.Entity.ToString();
                }
                //   Log.Info("playerEntered was " + playerEntered + " currentPLayer = " + currentPlayer + " controlled entity is " + pId);
                if (playerEntered != this.playerEntered) { 
                    SetPlayerStatus(playerEntered);                
                }
                if (playerEntered == true) {
      /**              IMyUserControllableGun gun = (IMyUserControllableGun)Entity;
                    Log.Info("is shooting? " + gun.IsShooting);
                   
                    if (gun.IsShooting)
                    {
                        MyAPIGateway.Utilities.ShowNotification("I am shooting now", 1000, MyFontEnum.Red);

                    } **/

                  //  Log.Info("Searching for projectiles");
                  //  MatrixD viewMatrix = MyAPIGateway.Session.CameraController.GetViewMatrix();

                    BoundingSphereD sphere = new BoundingSphereD(Entity.GetPosition()+Vector3.Normalize(Entity.WorldMatrix.Up)*2, 5);
                    MyAPIGateway.Entities.EnableEntityBoundingBoxDraw(Entity, true, new Vector4(255,100,100,100), 0.01f, null);
                  //  BoundingBoxD box = (BoundingBoxD)Entity.WorldAABB;
                    List<IMyEntity> entitiesFound = MyAPIGateway.Entities.GetEntitiesInSphere(ref sphere);

                //    IMyGunObject<MyGunBase> gunObject = ((IMyGunObject<MyGunBase>)Entity);
                //    MatrixD currentDummy = gunObject.GunBase.GetMuzzleWorldMatrix();
               //     Shoot(currentDummy.Translation, initialVelocity, currentDummy.Forward);


                    foreach (IMyEntity ent in entitiesFound)
                    {

                    //    Log.Info("found object of type: " + ent.GetType().ToString());
                        if (ent.GetType().ToString() == "Sandbox.Game.Weapons.MyMissile") //CHECK FOR OWNER OR SOMETHING ;_;
                        {
                            MyAPIGateway.Utilities.ShowNotification("I am shooting now", 1000, MyFontEnum.Red);
                            Ray directionRay = new Ray(ent.GetPosition(), Vector3.Normalize(ent.Physics.LinearVelocity));

                            BoundingSphereD largeSphere = new BoundingSphereD(Entity.GetPosition(), 20000);
                          //  MyAPIGateway.Entities.EnableEntityBoundingBoxDraw(Entity, true, new Vector4(255, 100, 100, 100), 0.01f, null);
                            //  BoundingBoxD box = (BoundingBoxD)Entity.WorldAABB;

                            
                            BoundingBox targetBox;
                            float lowestDistance = Single.MaxValue;
                            float safetyDistance = 10;
                            float? distance = 0;
                            IMyEntity bestTarget = null;
                          //  Log.Info("prepared math, starting iteration over found entities around me");
                            HashSet<IMyEntity> foundEntitySet = new HashSet<IMyEntity>();

                            for (float i = 10; i < 1000f; i += 10)
                            {
                                largeSphere = new BoundingSphereD(directionRay.Position + i * directionRay.Direction, 7.5);
                                foundEntitySet.UnionWith(MyAPIGateway.Entities.GetEntitiesInSphere(ref largeSphere));
                            }

                            foreach (IMyEntity foundEntity in foundEntitySet)
                            {
                                targetBox = (BoundingBox)foundEntity.GetTopMostParent().WorldAABB;
                                directionRay.Intersects(ref targetBox, out distance);
                               // Log.Info("iterating over : " + foundEntity.GetType());
                                if (distance != null)
                                {
                                //    Log.Info("distance wasnt zero for : " + foundEntity.GetType() + ", instead it was : " + distance);
                                    if (foundEntity.GetType().ToString() == "Sandbox.Game.Entities.MyCubeGrid") {
                                 //       Log.Info("one target has the name : " + foundEntity.DisplayName);
                                    }
                                    if (((float)distance < lowestDistance) && ((float)distance > safetyDistance)&&(foundEntity.GetTopMostParent().GetType().ToString()=="Sandbox.Game.Entities.MyCubeGrid"))
                                    {
                                        if (foundEntity != Entity) {
                                            bestTarget = foundEntity;
                                            lowestDistance = (float)distance;
                                            Log.Info("we found a fitting target: " + foundEntity.DisplayName);
                                            
                                        }

                                    }
                                }
                            }
                            if(bestTarget != null) AssignTarget(bestTarget);
                        }
                    }  
                }





            }
            catch (Exception e)
            {
                Log.Error(e);
                MyAPIGateway.Utilities.ShowNotification("" + e.ToString(), 1000, MyFontEnum.Red);
            }
        }
        public override void UpdateBeforeSimulation10()
        {
            try
            {
                
     /**       //    Log.Info("GameLogic " + Entity.GameLogic.Container.Get<GuidedMissileControlStationHook>());

                MyEntityComponentContainer componentContainer = Entity.Components;
           //     Log.Error("contains?" + componentContainer.Has<GuidedMissileControlStationHook>());
                //GuidedMissileTargetGridHook hook = componentContainer.Get<GuidedMissileTargetGridHook>();
                //Log.Info("success is not null?" + (hook != null));
                GuidedMissileControlStationHook controlStationHook;
                foreach (MyComponentBase comp in componentContainer) {
                    if (comp is GuidedMissileControlStationHook)
                    {
                        

                        controlStationHook = (GuidedMissileControlStationHook)comp;
                       // Log.Info("iterating over: " + comp.GetType().ToString());
                    }
                    }

                //      foreach (MyEntityComponentContainer component in componentList) {
                //          if (component is GuidedMissileTargetGridHook) {
                //              this.missileTarget = ((GuidedMissileTargetGridHook)component).GetMissileTarget();
                //             Log.Error("found a valid component!");
                //          }                
                //        } 



                //player in cockpit?
                //scan for entities in antenna range
                //filter for grid of certain mass
                //display as a list with clickables? or on hud with clickables on enemies
                // onClick for those, Grid-set target
             //   Log.Info("updating cockpit 10");
                //IMyHudObjectiveLine objective = MyAPIGateway.Utilities.GetObjectiveLine();
                bool playerEntered = false;
                IMyPlayerCollection allPlayers = MyAPIGateway.Players;
                IMyPlayer currentPlayer = null;
                List<IMyPlayer> playerList = new List<IMyPlayer>();
                allPlayers.GetPlayers(playerList, null);
                foreach (IMyPlayer player in playerList)
                {
                    if (player.Controller.ControlledEntity.Entity != null) {
                        if (player.Controller.ControlledEntity.Entity.EntityId == Entity.EntityId)
                        {
                            
                            if (MyAPIGateway.Session.Player == player)
                            {
                               // Log.Info("the correct player entered the command station");
                                currentPlayer = player;
                                if (playerEntered == false) playerEntered = true;
                            }
                        }
                    }
                }
                string pId = "";
                if (currentPlayer != null) {
                    if (currentPlayer.Controller.ControlledEntity.Entity != null) pId = currentPlayer.Controller.ControlledEntity.Entity.ToString();
                }
             //   Log.Info("playerEntered was " + playerEntered + " currentPLayer = " + currentPlayer + " controlled entity is " + pId);
                if(playerEntered != this.playerEntered) SetPlayerStatus(playerEntered);
                
                **/
              /**      Action<MyGuiControlButton> myAction = delegate(MyGuiControlButton button) {Log.Info("A button was clicked: " + button.ToString());};

                    var topLeftRelative = Vector2.One * -0.5f;
                    Vector2 leftColumnSize = new Vector2(0.3f, 0.55f);
                    var position = topLeftRelative + new Vector2(leftColumnSize.X + 0.503f, 0.42f);

                    var m_npcButton = new MyGuiControlButton(
                        position,
                        MyGuiControlButtonStyleEnum.Tiny,
                        new Vector2(0.1f, 0.1f),
                        null, MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_CENTER, "dis is test button", new StringBuilder("+"),
                        MyGuiConstants.DEFAULT_TEXT_SCALE, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, MyGuiControlHighlightType.WHEN_ACTIVE, true,
                        myAction, GuiSounds.MouseClick, 0.75f);
             //       Elements.Add(m_npcButton);
                    //
                    //    null, MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_CENTER, "dis is test button", new StringBuilder("+"),
                   //     MyGuiConstants.DEFAULT_TEXT_SCALE, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, MyGuiControlHighlightType.WHEN_ACTIVE, true,
               **/ 


            }
            catch (Exception e)
            {
                Log.Error(e);
                MyAPIGateway.Utilities.ShowNotification("" + e.ToString(), 1000, MyFontEnum.Red);
            }
        }
    }



    //       bool IMyUserControllableGun.IsShooting { get { return m_isShooting; } }
}


/**      Action<MyGuiControlButton> myAction = delegate(MyGuiControlButton button) {Log.Info("A button was clicked: " + button.ToString());};

      var topLeftRelative = Vector2.One * -0.5f;
      Vector2 leftColumnSize = new Vector2(0.3f, 0.55f);
      var position = topLeftRelative + new Vector2(leftColumnSize.X + 0.503f, 0.42f);

      var m_npcButton = new MyGuiControlButton(
          position,
          MyGuiControlButtonStyleEnum.Tiny,
          new Vector2(0.1f, 0.1f),
          null, MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_CENTER, "dis is test button", new StringBuilder("+"),
          MyGuiConstants.DEFAULT_TEXT_SCALE, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, MyGuiControlHighlightType.WHEN_ACTIVE, true,
          myAction, GuiSounds.MouseClick, 0.75f);
//       Elements.Add(m_npcButton);
      //
      //    null, MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_CENTER, "dis is test button", new StringBuilder("+"),
     //     MyGuiConstants.DEFAULT_TEXT_SCALE, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, MyGuiControlHighlightType.WHEN_ACTIVE, true,
 **/